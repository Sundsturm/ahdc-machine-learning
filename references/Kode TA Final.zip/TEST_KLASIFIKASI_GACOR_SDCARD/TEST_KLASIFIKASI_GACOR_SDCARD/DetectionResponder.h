#pragma once

namespace DetectionResponder {
  void setup();
  void respondToDetection(int classification, bool loggingEnabled);
}
