#pragma once

extern unsigned char model_tflite[];
extern unsigned int model_tflite_len;
